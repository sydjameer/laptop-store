from django.db import models

# Create your models here.
class Products(models.Model):
    prod_choices=(
    ('LP','Laptops'),
    ('DP','Desktops'),
    ('MB','Mobile'),
    ('MT','Monitors'),
    ('PT','Printers'),
    ('OT','Others'),
    ('AS','Accessories')
    )
    prod_name=models.CharField(max_length=260,choices=prod_choices,default='Laptops')

    def __str__(self):
        return self.prod_name


class ProductDetails(models.Model):
    product_category=models.ForeignKey(Products, on_delete=models.CASCADE)
    product_name=models.CharField(max_length=260)
    product_desc=models.TextField(null=True)
    product_model=models.CharField(max_length=260,blank=True)
    product_brand=models.CharField(max_length=260,blank=True)
    product_image=models.CharField(max_length=260,blank=True)
    promo_ind=models.BooleanField()
    product_actual_price=models.DecimalField(max_digits=10, decimal_places=2)
    product_sale_price=models.DecimalField(max_digits=10, decimal_places=2)
    product_field1=models.CharField(max_length=260,blank=True)
    product_field2=models.CharField(max_length=260,blank=True)
    product_field3=models.CharField(max_length=260,blank=True)
    product_field4=models.CharField(max_length=260,blank=True)
    product_field5=models.CharField(max_length=260,blank=True)
    product_field6=models.CharField(max_length=260,blank=True)
    product_field7=models.CharField(max_length=260,blank=True)
    product_field8=models.CharField(max_length=260,blank=True)
    product_field9=models.CharField(max_length=260,blank=True)
    product_field10=models.CharField(max_length=260,blank=True)
    product_textarea1=models.TextField(null=True)
    product_textarea2=models.TextField(null=True)

    def __str__(self):
        return self.product_name

class ImageUpload(models.Model):
    images=models.ImageField(upload_to = 'basic_app/static/images/product/',blank=False)

class CustomerEnquiry(models.Model):
    cust_firstname=models.CharField(max_length=260,blank=True)
    cust_lastname=models.CharField(max_length=260,blank=True)
    cust_phone=models.DecimalField(max_digits=8,decimal_places=0)
    cust_email=models.EmailField(max_length=260)
    cust_prod_name=models.CharField(max_length=260,blank=True)
    cust_prod_model=models.CharField(max_length=260,blank=True)
    cust_enquiry=models.TextField(null=True)

    def __str__(self):
        return self.cust_firstname
