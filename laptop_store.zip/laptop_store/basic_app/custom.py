from basic_app.models import ProductDetails,Products
import xlrd

class OpenExcel:

    def __init__(self,file):
        self.file=file
        with xlrd.open_workbook(filename=None, file_contents=self.file.read()) as workbook:
            self.worksheet = workbook.sheet_by_index(0)

    def col_count(self):
        colcount = 0
        for cols in range(0, self.worksheet.ncols):
            if self.worksheet.cell_value(0,cols) in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK):
                break
            else:
                colcount = colcount + 1

        return colcount

    def row_count(self):
        rowcount = 0
        for row in range(0, self.worksheet.nrows):
            if self.worksheet.cell_value(row, 1) in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK):
                break
            else:
                rowcount = rowcount + 1
        return(rowcount)

    def header(self):
        header_list=[]
        for j in range(self.col_count()):
            header_list.append(self.worksheet.cell_value(0,j))

        return(header_list)

    def row(self,row):
        rowvalue=[]
        for j in range(self.col_count()):
            rowvalue.append(self.worksheet.cell_value(row,j))

        return(rowvalue)

def handle_uploaded_file(f):
    myobj=OpenExcel(f)
    data={}
    rows=myobj.row_count()
    cols=myobj.col_count()
    header=myobj.header()


    for k in range(1,rows):
        data={}
        row_value = myobj.row(k)
        for index in range(0,cols):
            data[header[index]]=row_value[index]
        # print(data)

        product_id = Products.objects.get(prod_name=data['product_category'])
        new_product=ProductDetails(
            product_category=product_id,
            product_name=data['product_name'],
            product_desc=data['product_desc'],
            product_model=data['product_model'],
            product_brand=data['product_brand'],
            product_image=data['product_image'],
            promo_ind=data['promo_ind'],
            product_actual_price=data['product_actual_price'],
            product_sale_price=data['product_sale_price'],
            product_field1=data['product_field1'],
            product_field2=data['product_field2'],
            product_field3=data['product_field3'],
            product_field4=data['product_field4'],
            product_field5=data['product_field5'],
            product_field6=data['product_field6'],
            product_field7=data['product_field7'],
            product_field8=data['product_field8'],
            product_field9=data['product_field9'],
            product_field10=data['product_field10'],
            product_textarea1=data['product_textarea1'],
            product_textarea2=data['product_textarea2']
            )
        new_product.save()
        print('Product Saved Successfully')
