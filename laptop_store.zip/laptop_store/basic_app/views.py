from django.shortcuts import render
from django.http import HttpResponseRedirect,JsonResponse,HttpResponse
from django.views.generic import ListView,DetailView,TemplateView
from basic_app.models import ProductDetails,Products,ImageUpload
from django.views.decorators.csrf import csrf_exempt
from basic_app.forms import UploadFileForm,UploadImageForm,CustomerEnquiry
from basic_app.custom import handle_uploaded_file
from django.core.mail import send_mail
from . import models

# Create your views here.
def home(request):
    return render(request,'basic_app/index.html')

class ProductListView(ListView):
    context_object_name='products'
    template_name='basic_app/product_list.html'

    def get_queryset(self):
        self.product_id = Products.objects.get(prod_name=self.kwargs['key'])
        return ProductDetails.objects.filter(product_category=self.product_id)

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        context['product_ind']=True
        # print(context)
        return context

class ProductDetailsView(TemplateView):
    template_name='basic_app/productdetails.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        context['product_ind']=True
        context['detail']=ProductDetails.objects.get(id=self.kwargs['pk'])
        customerform=CustomerEnquiry()
        context['form']=customerform
        print(context)
        return context

@csrf_exempt
def customform(request):
    if request.method == 'POST':
        form=CustomerEnquiry(request.POST)
        if form.is_valid():
            userform=form.save(commit=False)
            userform.cust_prod_name=request.POST['prodname']
            userform.cust_prod_model=request.POST['prodmodel']
            userform.save()
            send_mail(
            'New Enquirey recieved from '+request.POST['cust_firstname']+request.POST['cust_lastname'],
             request.POST['cust_enquiry'],
            request.POST['cust_firstname'],
            ['djangotest@yopmail.com'],fail_silently=False,)

            data='Mail Sent Successfull. Thanks for your enquiry'
        else:
            data='Failed'
    return JsonResponse(data,safe=False)


class PromotionsListView(ListView):
    context_object_name='products'
    template_name='basic_app/product_list.html'

    def get_queryset(self):
        return ProductDetails.objects.filter(promo_ind=True)

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        context['product_ind']=True
        # send_mail('test_subject','hello','sydjamir@gmail.com',['sydjamir@gmail.com'],fail_silently=False,)
        # print(context)
        return context


class AllProductListView(ListView):
    context_object_name='products'
    template_name='basic_app/product_list.html'
    model=models.ProductDetails

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        context['product_ind']=True
        # print(context)
        return context

# To handle file uploads
def Fileupload(request):
    file_form=UploadFileForm()
    message='Please select the file to upload'
    # handle_uploaded_file(request.FILES['file'])
    if request.method == 'POST':
        if request.FILES['file']:
            excel_data=handle_uploaded_file(request.FILES['file'])
            file_form=UploadFileForm()
            message='File Uploaded Successfully'

    return render(request,'admin/admin_fileupload.html',{'file_form':file_form,'alert':message})

def Imageupload(request):
    file_form=UploadImageForm()
    message='Please select the file to upload'
    if request.method == 'POST':
        # Multiple File upload
        for item in request.FILES.getlist('images'):
            image_form=UploadImageForm(request.POST,{'images':item})
            if image_form.is_valid():
                image_form.images = item
                image_form.save()
        message='Image(s) Uploaded Successfully'

        # Single Image file upload
        # image_form=UploadImageForm(request.POST,request.FILES)
        # if image_form.is_valid():
        #
        #     image_form.images = request.FILES['images']
        #     image_form.save()
        #     message='Image(s) Uploaded Successfully'

    return render(request,'admin/admin_imageupload.html',{'file_form':file_form,'alert':message})
