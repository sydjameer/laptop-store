from django import forms
from basic_app.models import ImageUpload,CustomerEnquiry

class UploadFileForm(forms.Form):
    file=forms.FileField(widget=forms.FileInput)

class UploadImageForm(forms.ModelForm):
    images=forms.ImageField(widget=forms.FileInput(attrs={'multiple':True}))
    class Meta():
        model=ImageUpload
        fields=('images',)

class CustomerEnquiry(forms.ModelForm):

    class Meta():
        model=CustomerEnquiry
        exclude=('cust_prod_model','cust_prod_name',)
