console.log("Your main.js is working");
// Settings

$("#enquire").click(function(){
  $("#exampleModal").modal();
});


window.localStorage
$(".badge").text(sessionStorage.cartcount);

function Slider1(){
  document.getElementById("cartbox").classList.toggle("active");
  console.log("cart is clicked");
}

$("#clearcart").click(function(){
sessionStorage.clear();
$(".badge").text("0");
});

$("input[name='addtocart']").click(
  function(){
      $(".badge").text(function(){
      cart=Number($(".badge").text())+1
      sessionStorage.setItem('cartcount',cart)
      // $.post('/store/cartinfo/',{'cartcount':cartMemory},function(data,success){
      //   // console.log(data);
      // });
      return cart;
    })
  }
);
