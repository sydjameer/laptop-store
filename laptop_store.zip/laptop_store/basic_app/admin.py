from django.contrib import admin
from basic_app.models import Products,ProductDetails,ImageUpload,CustomerEnquiry

# Register your models here.
admin.site.register(Products)
admin.site.register(ProductDetails)
admin.site.register(CustomerEnquiry)
