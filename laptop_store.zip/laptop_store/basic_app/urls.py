from django.contrib import admin
from django.urls import path
from basic_app import views

app_name='store'

urlpatterns = [
    path(r'product/?<key>$/',views.ProductListView.as_view(),name='product'),
    path(r'allproducts/',views.AllProductListView.as_view(),name='all_products'),
    path(r'promotions/',views.PromotionsListView.as_view(),name='promotions'),
    path('fileupload/',views.Fileupload,name='fileupload'),
    path('imageupload/',views.Imageupload,name='imageupload'),
    path(r'?<pk>$/',views.ProductDetailsView.as_view(),name='productdetails'),
    path('customerform/',views.customform,name='customerform'),
]
